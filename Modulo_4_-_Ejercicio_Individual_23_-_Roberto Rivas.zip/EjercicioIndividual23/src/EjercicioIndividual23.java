import java.util.Scanner;

public class EjercicioIndividual23 {


    public static void main(String[] args){

        Scanner leer = new Scanner(System.in);
        StringBuilder resultado = new StringBuilder();

        String palabra = "";

        System.out.println("Ingrese una palabra");
        palabra = leer.nextLine();

        for (int i = 0; i < palabra.length(); i++) {
            char caracter = palabra.charAt(i);

            if (Character.isLowerCase(caracter)) {
                resultado.append(Character.toUpperCase(caracter));
            } else if (Character.isUpperCase(caracter)) {
                resultado.append(Character.toLowerCase(caracter));
            } else if (caracter == ' ') {
                continue;
            } else {
                resultado.append(caracter);
            }
        }

        System.out.println(resultado);


    }
}
